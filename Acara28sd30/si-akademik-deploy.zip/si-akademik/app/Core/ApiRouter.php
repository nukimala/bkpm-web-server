<?php
// app/Core/ApiRouter.php
// Router API (RESTful): mencocokkan HTTP method + URI dengan route api (Acara 16).
// Format route: 'METHOD /api/path' => 'Controller@method'.
require_once __DIR__ . '/ApiResponse.php';
require_once __DIR__ . '/Database.php';

class ApiRouter
{
    // Dispatch request API. Memisahkan 404 (path tidak ada) dan 405 (method salah).
    public static function dispatch(string $uri, string $method): void
    {
        $routes = require __DIR__ . '/../../routes/api.php';
        $method = strtoupper($method);
        $pathMatched = false;

        foreach ($routes as $key => $handler) {
            [$routeMethod, $routePath] = preg_split('/\s+/', trim($key), 2);

            $pattern = preg_replace(
                '#\{([a-zA-Z0-9_]+)\}#',
                '(?P<$1>[0-9a-zA-Z_]+)',
                trim($routePath, '/')
            );

            if (preg_match('#^' . $pattern . '$#', $uri, $m)) {
                $pathMatched = true;

                if ($method !== strtoupper($routeMethod)) {
                    continue;
                }

                [$controllerName, $controllerMethod] = explode('@', $handler);
                $params = array_filter($m, function ($key) {
                    return !is_int($key);
                }, ARRAY_FILTER_USE_KEY);

                // Acara 19 & 25: Proteksi token dan RBAC.
                // Endpoint pemodifikasi data (POST, PUT, DELETE) wajib memiliki role admin (requireAdmin),
                // kecuali login (publik) dan logout (memerlukan token pengguna apapun).
                if ($method !== 'GET') {
                    require_once __DIR__ . '/Middleware/ApiAuthMiddleware.php';
                    if ($routePath === '/api/auth/logout') {
                        ApiAuthMiddleware::validate();
                    } elseif ($routePath !== '/api/auth/login') {
                        ApiAuthMiddleware::requireAdmin();
                    }
                }

                $controllerFile = str_replace('\\', '/', $controllerName);
                $controllerClass = basename($controllerFile);
                require_once __DIR__ . '/../Controllers/' . $controllerFile . '.php';
                $controller = new $controllerClass();
                $controller->$controllerMethod(...array_values($params));
                return;
            }
        }

        if ($pathMatched) {
            ApiResponse::error('Metode HTTP tidak diizinkan untuk endpoint ini.', 405);
        }
        ApiResponse::error('Endpoint API tidak ditemukan.', 404);
    }

    // Membaca body request (mendukung JSON dan multipart/form-data untuk upload berkas Acara 26)
    public static function input(): array
    {
        if (!empty($_POST)) {
            return $_POST;
        }

        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
}